package com.selenium4corebasics.day6;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;

public class Screenshot {

	public static void main(String[] args) throws IOException {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\Dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://testsigma.com/");
		driver.manage().window().maximize(); // minimizes the browser
		WebElement sourceElement = driver.findElement(By.xpath("//a[text()='Product']"));

		WebElement secondElement = driver.findElement(By.xpath("//a[contains(text(),'Web Application Testing')]"));

		Actions acc = new Actions(driver);
		acc.moveToElement(sourceElement).moveToElement(secondElement).click().perform();

		String url = driver.getCurrentUrl();

		if (url.contains("automated-web-application-automation")) {
			System.out.println("test case passed");
		} else {
			System.out.println("test case failed");
			// screenshot code
			TakesScreenshot tk = (TakesScreenshot) driver;// typescasting 
			File source = tk.getScreenshotAs(OutputType.FILE); // specifying the file type
			File destination = new File(
					System.getProperty("user.dir") + "\\src\\com\\seleniumdemo\\day4\\screenshot.png");
			FileHandler.copy(source, destination);
		}
		driver.quit();
	}
}
