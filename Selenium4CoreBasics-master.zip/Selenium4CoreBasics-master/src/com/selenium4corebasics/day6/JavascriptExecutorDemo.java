package com.selenium4corebasics.day6;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;

public class JavascriptExecutorDemo {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\Dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://testsigma.com/automated-web-application-testing");
		driver.manage().window().maximize();
		WebElement element = driver.findElement(By.xpath("//h3[contains(text(),'Debugging')]"));
		
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element); 
		WebElement scrollUp = driver.findElement(By.xpath("//a[contains(text(),'Sign up for free')]"));
		js.executeScript("arguments[0].scrollIntoView(true);", scrollUp);
		
		js.executeScript("arguments[0].click();", scrollUp);// clicking 
		js.executeScript("arguments[0].setAttribute('value','shatish');", driver.findElement(By.id("email"))); // typing 
		
		
		Thread.sleep(3000);
		driver.quit();
	}

}
