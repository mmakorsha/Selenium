package com.selenium4corebasics.day8;

import java.time.Duration;

import javax.swing.Action;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumWaits {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.selenium.dev/selenium/web/dynamic.html");
		Wait<WebDriver> wait = new WebDriverWait(driver, Duration.ofSeconds(20));
//		Wait<WebDriver> wait = new FluentWait<>(driver).pollingEvery(Duration.ofMillis(100))
//				.withTimeout(Duration.ofSeconds(20)).ignoring(Exception.class);
		WebElement firstClick = driver.findElement(By.id("reveal"));
//		wait.until(ExpectedConditions.visibilityOf(firstClick));
		wait.until(d -> firstClick.isDisplayed());
		firstClick.click();
//			Thread.sleep(5000); - not recommended
		WebElement newElement = driver.findElement(By.id("revealed"));
		wait.until(ExpectedConditions.visibilityOf(newElement));
		newElement.sendKeys("shatish");
		Thread.sleep(5000);
		Actions acc = new Actions(driver);
		acc.keyDown(Keys.ENTER).keyUp(Keys.ENTER).perform();
		driver.quit();
	}

}
