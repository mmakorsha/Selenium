package com.selenium4corebasics.day8;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitsFluentWaitDemo2 {
	/*
	 * we wait for a certain condition
	 * 
	 * 
	 * 
	 * Note : Warning: Do not mix implicit and explicit waits. Doing so can cause
	 * unpredictable wait times. For example, setting an implicit wait of 10 seconds
	 * and an explicit wait of 15 seconds could cause a timeout to occur after 20
	 * seconds.
	 * 
	 * Reason : it stars with visibilty condition (15 sec time ) . go for find the
	 * elemnt implicit wait gets added before control goes to visibility again it
	 * would have waited for 10 sec then checks for visibility condition timeout
	 * (not exceed : 5 more secs ) go for find the element implicit wait gets added
	 * before control goes to visibility again it would have waited for 10 sec then
	 * checks for visibility condition timeout (exceed : 20 secs)
	 * 
	 */

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); // selenium 3 and before 
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); // selenium 4
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
		driver.get("https://www.facebook.com");

//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20)); // 500 ms
		
		Wait<WebDriver> wait = new FluentWait<>(driver)
								.pollingEvery(Duration.ofMillis(100))
								.withTimeout(Duration.ofSeconds(20))
								.ignoring(Exception.class);
		
		
		WebElement ele_create_new_account = wait.until(
				ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//a[text()='Create new account']"))));
		ele_create_new_account.click();

//		WebElement dropDownElement = driver.findElement(By.id("day"));
		WebElement dropDownElement = wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("day"))));
		wait.until(ExpectedConditions.elementToBeClickable(dropDownElement));

		Select select = new Select(dropDownElement);
		select.selectByValue("10");
		System.out.println("selected value : " + dropDownElement.getAttribute("value"));
		
		ExpectedConditions.frameToBeAvailableAndSwitchToIt(driver.findElement(By.tagName("iframe")));
		ExpectedConditions.alertIsPresent();
		ExpectedConditions.visibilityOf(dropDownElement);
		ExpectedConditions.elementToBeClickable(dropDownElement);
		
	}

}
