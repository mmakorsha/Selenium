package com.selenium4corebasics.day8;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class WaitsImplicitDemo {
	
	//implicitWait - 
			// default value is 0
			/*
			 * used for findElement and findElements 
			 * set it once and applicable for entire execution 
			 */
	
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS); // selenium 3 and before 
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30)); // selenium 4
		driver.get("https://www.facebook.com");
		driver.findElement(By.xpath("//a[text()='Create new account']")).click();
		WebElement dropDownElement = driver.findElement(By.id("day"));
		Select select = new Select (dropDownElement);
		select.selectByValue("10");
		System.out.println("selected value : " + dropDownElement.getAttribute("value"));
	}

}
