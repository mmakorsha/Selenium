# Selenium WebDriver Wait Commands

## What are Wait commands in Selenium?

The wait commands are essential when it comes to executing Selenium tests. They help to observe and troubleshoot issues that may occur due to variation in time lag.

While running Selenium tests, it is common for testers to get the message �Element Not Visible Exception�. This appears when a particular web element with which WebDriver has to interact, is delayed in its loading. To prevent this Exception, Selenium Wait Commands must be used.

In automation testing, Selenium Webdriver wait commands direct test execution to pause for a certain length of time before moving onto the next step. This enables WebDriver to check if one or more web elements are present/visible/enriched/clickable, etc.

## Types of Wait Commands in Selenium

### 1. Implicit Wait

- Implicit Wait directs the Selenium WebDriver to wait for a certain measure of time before throwing an exception. Once this time is set, WebDriver will wait for the element before the exception occurs.

- Once the command is run, Implicit Wait remains for the entire duration for which the browser is open.

   ```java
   driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
   ```

### 2. Explicit Wait

- By using the Explicit Wait command, the WebDriver is directed to wait until a certain condition occurs before proceeding with executing the code.

- Setting Explicit Wait is important in cases where there are certain elements that naturally take more time to load.

   ```java
   WebDriverWait wait = new WebDriverWait(driver,30);
   ```

### 3. Fluent Wait

- Fluent Wait in Selenium marks the maximum amount of time for Selenium WebDriver to wait for a certain condition (web element) becomes visible. It also defines how frequently WebDriver will check if the condition appears before throwing the �ElementNotVisibleException�.

   ```java
   FluentWait wait = new FluentWait(driver);
   wait.withTimeout(5000, TimeUnit.MILLISECONDS);
   wait.pollingEvery(250, TimeUnit.MILLISECONDS);
   wait.ignoring(NoSuchElementException.class);
   ```

## Note

- Keep in mind that Implicit Wait may increase test script execution time. It makes each command wait for the defined time before resuming test execution.

- It's important to choose between Implicit and Explicit waits based on the specific needs of your test case.

## Associated Commands

- PageLoadTimeout Command
- SetScriptTimeout Command
- Sleep Command

## Difference between Implicit and Explicit Wait Commands

|                    | Implicit Wait in Selenium                                   | Explicit Wait in Selenium                             |
|--------------------|-----------------------------------------------------------|------------------------------------------------------|
| Applies to         | All elements in a test script                                | Specific elements as intended by the user            |
| ExpectedConditions | Not required                                              | Must always specify ExpectedConditions               |
| Effectiveness      | Effective for elements located within the specified time   | Effective for elements taking a long time to load    |
