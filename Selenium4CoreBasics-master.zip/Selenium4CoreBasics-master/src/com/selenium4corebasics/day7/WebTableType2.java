package com.selenium4corebasics.day7;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTableType2 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.techlistic.com/2017/02/automate-demo-web-table-with-selenium.html");
		driver.manage().window().maximize();
		List<WebElement> tRow = driver.findElements(By.xpath("//table[@id='customers']/tbody/tr"));
		List<List<String>> tableInfo = new ArrayList<>();
		for (int i = 0; i < tRow.size(); i++) {
			List<WebElement> tdata = tRow.get(i).findElements(By.tagName("td"));
//			System.out.println("Printing " + i + " row elements");
			List<String> rowInfo = new ArrayList<>();
			for (int j = 0; j < tdata.size(); j++) {
//				System.out.println();
				rowInfo.add(tdata.get(j).getText());
			}
			tableInfo.add(rowInfo);
		}
		//print all rows using loopss

//		for (int i = 0; i < tableInfo.size(); i++) {
//			for (int j = 0; j < tableInfo.get(i).size(); j++) {
//				System.out.println(tableInfo.get(i).get(j));
//			}
//		}

		// print only the first row
		System.out.println(tableInfo.get(1).get(0));
		System.out.println(tableInfo.get(1).get(1));
		System.out.println(tableInfo.get(1).get(2));
		driver.quit();
	}

}
