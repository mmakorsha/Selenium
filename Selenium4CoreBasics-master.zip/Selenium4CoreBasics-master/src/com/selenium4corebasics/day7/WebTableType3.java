package com.selenium4corebasics.day7;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTableType3 {

	public static String getDataFromTable(WebDriver driver, String name) {
		return driver.findElement(By.xpath("//span[text()='" + name + "']/parent::td/parent::tr/td[3]")).getText();
	}
	
	public static String getDataFromTableUsingLoops(WebDriver driver, String name) {
		String countryName = null;
		List<WebElement> name_company = driver.findElements(By.xpath("//table[@id='customers']/tbody/tr/td[1]"));
			for (int i = 0 ; i < name_company.size() ; i ++) {
				if (name_company.get(i).getText().trim().equalsIgnoreCase(name)) {
					countryName = driver.findElement(By.xpath("//table[@id='customers']/tbody/tr["+(i+2)+"]/td[3]")).getText();
				}
			}
			return countryName;
	}

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.techlistic.com/2017/02/automate-demo-web-table-with-selenium.html");
		driver.manage().window().maximize();
		System.out.println(getDataFromTable(driver, "Microsoft"));
		System.out.println(getDataFromTableUsingLoops(driver, "Microsoft"));
		driver.quit();
	}
}
