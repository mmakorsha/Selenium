## Overview

An iFrame in Selenium Webdriver refers to a web page or an inline frame that is embedded within another web page or HTML document. It allows for the integration of external content, such as advertisements, into a web page seamlessly. The iFrame is defined using the `<iframe>` tag in HTML.

# Handling Frames in Selenium using WebDriver Commands

When working with frames in Selenium, there are three primary methods for switching between elements:

1. **By Index**
2. **By Name or Id**
3. **By Web Element**

## Method 1: Switch to the Frame by Index

The index is one of the attributes used for frame handling in Selenium. It allows us to switch to a specific frame based on its position.

- Indexing for frames starts from `0`.
- For example, if there are 100 frames on a page, you can switch to a frame using its index.

### Example:

driver.switchTo().frame(0);
driver.switchTo().frame(1);

## Method 2: Switch to the Frame by Name or ID

Name and ID are attributes used for handling frames in Selenium. They enable us to switch to a frame by referring to its assigned name or ID.

### Example:

driver.switchTo().frame("iframe1");
driver.switchTo().frame("id of the element");

## Method 3: Switch to the Frame by Web Element

You can also switch to the iframe using a web element.

### Example:

WebElement iframeElement = driver.findElement(By.id("iframe_id"));
driver.switchTo().frame(iframeElement);

## Switching Back to the Main Frame

To return to the parent frame or the main (most parent) frame, you can use the following commands:

driver.switchTo().parentFrame();
driver.switchTo().defaultContent();

# Concept of Nested Frames in Selenium

In certain scenarios, frames can be nested, meaning one frame is contained within another. This requires a specific approach for interaction.

When dealing with nested frames in Selenium, follow these steps:

1. **Switch to the Outer Frame:**
   - Use either the index or ID of the outer frame to switch to it.

2. **Determine the Number of Frames within the Outer Frame:**
   - Once within the outer frame, identify the total number of iframes it contains.

3. **Switch to the Inner Frame:**
   - Using any of the known methods, switch to the desired inner frame.

4. **Perform Actions within the Inner Frame:**
   - Interact with elements inside the inner frame.

5. **Exit Frames in Reverse Order:**
   - When done, exit the inner frame first, then return to the outer frame.