package com.selenium4corebasics.day7;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTableType1 {

	public static String getDataFromTable(WebDriver driver, int row, int column) {
		return driver.findElement(By.xpath("//table[@id='customers']/tbody/tr[" + row + "]/td[" + column + "]"))
				.getText();
	}

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.techlistic.com/2017/02/automate-demo-web-table-with-selenium.html");
		driver.manage().window().maximize();
		System.out.println(getDataFromTable(driver, 2, 1));
		System.out.println(getDataFromTable(driver, 2, 2));
		System.out.println(getDataFromTable(driver, 2, 3));
		driver.quit();
	}

}
