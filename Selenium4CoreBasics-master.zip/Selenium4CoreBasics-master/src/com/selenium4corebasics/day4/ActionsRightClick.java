package com.selenium4corebasics.day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionsRightClick {
	/*
	 * This class is used to perform complex actions like drag and drop, double
	 * click, right click, mouse hovering)
	 * For using this class we need to create object for the class as below 
	 * Actions action = new Actions (driver); 
	 * and use the methods using action object
	 * 
	 * Must always end with perform() method else will not work
	 */
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.guru99.com/test/simple_context_menu.html");
		WebElement ele_rightClick = driver.findElement(By.xpath("(//*[text()='right click me'])[1]"));

		Actions action = new Actions(driver);
		action.contextClick(ele_rightClick).perform();
		Thread.sleep(3000);
		boolean displayed = driver.findElement(By.xpath("//li/span[text()='Edit']")).isDisplayed();
		if (displayed) {
			System.out.println(" right click passed");
		} else {
			System.out.println("right click failed");
		}

		// doubleclick 
		WebElement ele_doubleClick = driver.findElement(By.tagName("button"));
		action.doubleClick(ele_doubleClick).perform();
		Thread.sleep(3000);
		driver.quit();
	}

}
