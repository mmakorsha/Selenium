package com.selenium4corebasics.day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionsDragAndDrop {
	/*
	 * This class is used to perform complex actions like drag and drop, double click, right click, mouse hovering)
	 * For using this class we need to create oject for the class as below 
	 * 	Actions action = new Actions (driver);
	 * and use the methods using action object 
	 * 
	 * Must always end with perform() method else will not work
	 */
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.guru99.com/test/drag_drop.html");
		WebElement ele_drag = driver.findElement(By.xpath("(//li[@data-id='2'])[1]"));
		WebElement ele_drop = driver.findElement(By.id("amt7"));
		
		Actions action = new Actions(driver);
		action.dragAndDrop(ele_drag, ele_drop).perform();
//		action.clickAndHold(ele_drag).moveToElement(ele_drop).release().perform();
		Thread.sleep(3000);
		driver.quit();
	}

}
