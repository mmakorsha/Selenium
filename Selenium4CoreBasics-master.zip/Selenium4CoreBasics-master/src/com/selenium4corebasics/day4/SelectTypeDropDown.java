package com.selenium4corebasics.day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectTypeDropDown {

	/*
	 * We Need to use Select Class for handling drop down whose HTML tag is Select
	 * Methods of Select Class : 
	 * 			1) selectByValue() 
	 * 			2) selectByIndex()
	 * 			3) selectByVisibleText()
	 * 			4) getAllSelectedOtptions()
	 * 			5) getFirstSelectedOtpion()
	 * 			6) isMultiple()
	 * 			7) deselectByValue()
	 * 			8) deselectByIndex()
	 * 			9) deselectByVisibleText()
	 * 			10)deselectAll()
	 * First we need to use the select class option 
	 * 			Select select = new Select (dropdown webelement)
	 * using the select class object we can access the above mentioned methods 
	 */

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com");
		driver.findElement(By.xpath("//a[text()='Create new account']")).click();
		Thread.sleep(3000); // waiting for 3 sec for the elements to appear
		WebElement dropDownElement = driver.findElement(By.id("day"));
		// creating object for Select class 
		Select select = new Select (dropDownElement);
		select.selectByValue("10");
		System.out.println("selected value : " + dropDownElement.getAttribute("value"));
		select.selectByIndex(1); // index start with 0
		System.out.println("selected value : " + dropDownElement.getAttribute("value"));
		select.selectByVisibleText("4");
		System.out.println("selected value : " + dropDownElement.getAttribute("value"));

	}

}
