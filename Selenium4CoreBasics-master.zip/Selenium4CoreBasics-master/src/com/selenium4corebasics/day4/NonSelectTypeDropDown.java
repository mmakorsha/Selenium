package com.selenium4corebasics.day4;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class NonSelectTypeDropDown {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.makemytrip.com/");
		Thread.sleep(5000);
		driver.findElement(By.id("fromCity")).click();
		Thread.sleep(2000);
		List<WebElement> allDpElements = driver.findElements(By.xpath("//ul[@role='listbox']/li"));
		for (int i = 0; i < allDpElements.size(); i++) {
			System.out.println(allDpElements.get(i).getText());
			if (allDpElements.get(i).getText().trim().contains("Pune Airport")) {
				allDpElements.get(i).click();
				break;
			}
		}

	}

}
