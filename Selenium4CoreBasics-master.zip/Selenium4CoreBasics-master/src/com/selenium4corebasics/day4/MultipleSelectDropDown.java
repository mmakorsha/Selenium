package com.selenium4corebasics.day4;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class MultipleSelectDropDown {
	
	//excercise : https://www.lambdatest.com/selenium-playground/select-dropdown-demo

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.tutorialspoint.com/selenium/selenium_automation_practice.htm");
		WebElement dropDownElement = driver.findElement(By.name("selenium_commands"));
		// creating object for Select class

		Select select = new Select(dropDownElement);
		// check if the drop down is multi select or not
		Boolean bool = select.isMultiple();
		System.out.println("is multi select drop down : " + bool);
		if (select.isMultiple()) {
			select.selectByIndex(0);
			select.selectByVisibleText("Navigation Commands");
		}

		List<WebElement> allSelectedOptions = select.getAllSelectedOptions();
		System.out.println("printing all the selected options");
		for (int i = 0; i < allSelectedOptions.size(); i++) {
			System.out.println(allSelectedOptions.get(i).getText().trim());
		}

		System.out.println("printing the first selected option : " + select.getFirstSelectedOption().getText());

		select.deselectByVisibleText("Navigation Commands");

		System.out.println("number of selected options after deselecting : " + select.getAllSelectedOptions().size());
	}

}
