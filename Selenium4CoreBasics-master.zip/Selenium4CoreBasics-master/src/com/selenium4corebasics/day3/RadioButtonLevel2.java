package com.selenium4corebasics.day3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioButtonLevel2 {

	public static void selectGender(WebDriver driver, String option) {
		/*
		 * Rather than having loops - another approach is using dynamic locator strategy
		 * Here instead of using static locators we are passing dynamic values to the
		 * locator in runtime.
		 */
		WebElement ele_femaleRadio = driver
				.findElement(By.xpath("//label[text()='" + option + "']//following-sibling::input"));
		System.out.println("status of radio button before selecting : " + ele_femaleRadio.isSelected()); //  output : false
		if (!ele_femaleRadio.isSelected()) {
			ele_femaleRadio.click();
			System.out.println("status of radio button after selecting : " + ele_femaleRadio.isSelected()); // output : true
		}
	}

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com");
		driver.findElement(By.xpath("//a[text()='Create new account']")).click();
		Thread.sleep(3000); // waiting for 3 sec for the elements to appear
		selectGender(driver, "Male");
		driver.quit();
	}

}
