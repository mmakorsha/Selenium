package com.selenium4corebasics.day3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckBoxLevel3 {

	public static void selectCheckBox(WebDriver driver, String option) {
		List<WebElement> ele_checkbox = driver.findElements(By.xpath("//input[@type='checkbox']"));
		for (int i = 0; i < ele_checkbox.size(); i++) {
			if (ele_checkbox.get(i).getAttribute("value").trim().equalsIgnoreCase(option)
					&& !ele_checkbox.get(i).isSelected()) {
				ele_checkbox.get(i).click();
			}
		}

	}

	public static void deSelectCheckBox(WebDriver driver, String option) {
		List<WebElement> ele_checkbox = driver.findElements(By.xpath("//input[@type='checkbox']"));
		for (int i = 0; i < ele_checkbox.size(); i++) {
			if (ele_checkbox.get(i).getAttribute("value").trim().equalsIgnoreCase(option)
					&& ele_checkbox.get(i).isSelected()) {
				ele_checkbox.get(i).click();
			}
		}
	}

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.guru99.com/test/radio.html");
		selectCheckBox(driver, "checkbox2");
		selectCheckBox(driver, "checkbox1");
		deSelectCheckBox(driver, "checkbox2");
		deSelectCheckBox(driver, "checkbox3");
		driver.quit();
	}

}
