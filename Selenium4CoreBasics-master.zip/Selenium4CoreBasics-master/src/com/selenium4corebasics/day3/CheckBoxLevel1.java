package com.selenium4corebasics.day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckBoxLevel1 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.guru99.com/test/radio.html");
		WebElement ele_checkbox1 = driver.findElement(By.xpath("//input[@value='checkbox1']"));
		System.out.println("status of check box before selecting : " + ele_checkbox1.isSelected()); // output : false
		if (!ele_checkbox1.isSelected()) {
			ele_checkbox1.click();
		}
		System.out.println("status of check box before selecting : " + ele_checkbox1.isSelected()); // output : false
		ele_checkbox1.click(); // if clicking again the check box gets deselected so the above if block is
								// important
		System.out.println("status of check box before de-selecting : " + ele_checkbox1.isSelected()); // output : false
		// deselecting the checkbox
		if (ele_checkbox1.isSelected()) { // this block gets executed only if the check box is already selected
			ele_checkbox1.click();
		}
		driver.quit();
	}

}
