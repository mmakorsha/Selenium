package com.selenium4corebasics.day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckBoxLevel2 {

	public static void selectCheckBox(WebDriver driver, String option) {
		WebElement ele_checkbox = driver.findElement(By.xpath("//input[@value='" + option + "']"));
		if (!ele_checkbox.isSelected()) {
			ele_checkbox.click();
		}
	}

	public static void deSelectCheckBox(WebDriver driver, String option) {
		WebElement ele_checkbox = driver.findElement(By.xpath("//input[@value='" + option + "']"));
		if (ele_checkbox.isSelected()) {
			ele_checkbox.click();
		}
	}

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.guru99.com/test/radio.html");
		WebElement ele_checkbox1 = driver.findElement(By.xpath("//input[@value='checkbox1']"));
		selectCheckBox(driver, "checkbox2");
		selectCheckBox(driver, "checkbox1");
		deSelectCheckBox(driver, "checkbox2");
		deSelectCheckBox(driver, "checkbox3");
		driver.quit();
	}

}
