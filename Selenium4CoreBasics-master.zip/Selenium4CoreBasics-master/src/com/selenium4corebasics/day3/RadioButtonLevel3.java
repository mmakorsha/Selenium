package com.selenium4corebasics.day3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioButtonLevel3 {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com");
		driver.findElement(By.xpath("//a[text()='Create new account']")).click();
		Thread.sleep(3000); // waiting for 3 sec for the elements to appear
		/*
		 * Note : In real time the locators are identified in such a way that all radio
		 * button elements corresponds to gender are selected using a single locator and
		 * using loops to iterate and click on the desired locator
		 */
		List<WebElement> ele_genderRadioLabel = driver
				.findElements(By.xpath("//input[@type='radio']/preceding-sibling::label"));
		List<WebElement> ele_genderRadioButton = driver.findElements(By.xpath("//input[@type='radio']"));
		System.out.println("number of options : " + ele_genderRadioLabel.size()); // printing the number of options
																					// present (o/p : 3)
		for (int i = 0; i < ele_genderRadioLabel.size(); i++) {
			if (ele_genderRadioLabel.get(i).getText().trim().equalsIgnoreCase("Male")) {// string can be changed to any option (can use reusable method to achive this)
				if (!ele_genderRadioButton.get(i).isSelected()) {
					ele_genderRadioButton.get(i).click();
					System.out.println(
							"status of radio button after selecting : " + ele_genderRadioButton.get(i).isSelected()); //true																								// true
					 // using break statement is good practice as we can terminate the loops once the desired condition is achieved
					break;
				}
			}

		}
		driver.quit();
	}

}
