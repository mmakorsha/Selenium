package com.selenium4corebasics.day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioButtonLevel1 {
	
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com");
		driver.findElement(By.xpath("//a[text()='Create new account']")).click();
		Thread.sleep(3000); // waiting for 3 sec for the elements to appear
		WebElement ele_femaleRadio = driver.findElement(By.xpath("//label[text()='Female']//following-sibling::input"));
		System.out.println("status of radio button before selecting : " + ele_femaleRadio.isSelected()); //  output : false
		/* Note : 
		 *  The if block executes only if the radio button is not selected
		 *  This validation is very important for checkbox as for the checkbox if is
		 *  clicked more than once then it is deselect
		 */
		if (!ele_femaleRadio.isSelected()) { // checking whether the radio button is selected
			ele_femaleRadio.click();
		}
		System.out.println("status of radio button after selecting : " + ele_femaleRadio.isSelected()); // output : true
		driver.quit();
	}

}
