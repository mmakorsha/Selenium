package com.selenium4corebasics.day5;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alerts2 {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demo.automationtesting.in/Alerts.html");
		driver.findElement(By.cssSelector("a[href*=Text]")).click();
		
		driver.findElement(
					By.xpath("//button[contains(text(),'click the button to demonstrate the prompt box')]")).click();
		
		Alert alert = driver.switchTo().alert();
		alert.sendKeys("shatish");
		alert.accept(); // dismiss // sendKeys // getText()
		Thread.sleep(3000);
		
		driver.quit();

	}

}
