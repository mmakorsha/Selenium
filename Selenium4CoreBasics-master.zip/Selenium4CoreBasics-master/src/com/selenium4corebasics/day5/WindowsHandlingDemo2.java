package com.selenium4corebasics.day5;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowsHandlingDemo2 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://nxtgenaiacademy.com/multiplewindows/");
		System.out.println("Before switching : " + driver.getCurrentUrl());

		driver.findElement(By.xpath("//button[text()='New Browser Tab']")).click();

		// getWindowHandle() - returns string of parent ID
		// getWindowHandles() - returns Set<String> of all window IDs

		String parentId = driver.getWindowHandle();
		Set<String> allWindow = driver.getWindowHandles();
//		for (String child : allWindow) {
//			if (!parentId.equals(child)) {
//				driver.switchTo().window(child);
//				break;
//			}
//		}
		Iterator<String> i = allWindow.iterator();

		while (i.hasNext()) {
			String child = i.next();
			if (!parentId.equals(child)) {
				driver.switchTo().window(child);
				break;
			}

		}

		System.out.println("After switching : " + driver.getCurrentUrl());
		driver.close();
		driver.switchTo().window(parentId);
		System.out.println("After closing : " + driver.getCurrentUrl());
		driver.quit();
	}

//	A45DB00EF2DDE115875BEAD5B7D0EF45
//	
//	[A45DB00EF2DDE115875BEAD5B7D0EF45, 18F9125AC8E026184643F592076F962B]

}
