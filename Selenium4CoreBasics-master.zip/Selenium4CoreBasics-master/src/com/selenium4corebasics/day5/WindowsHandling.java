package com.selenium4corebasics.day5;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowsHandling {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://nxtgenaiacademy.com/multiplewindows/");
		System.out.println("before switching : " + driver.getCurrentUrl());
		driver.findElement(By.xpath("//button[text()='New Browser Tab']")).click();
		String parent = driver.getWindowHandle();
		Set<String> allWindows = driver.getWindowHandles();
//		Iterator<String> iterator = allWindows.iterator();
//		while (iterator.hasNext()) {
//			String child = iterator.next();
//			if (!parent.equals(child)) {
//				driver.switchTo().window(child);
//				break;
//			}
//		}

//		for (String child : allWindows) {
//			if (!parent.equals(child)) {
//				driver.switchTo().window(child);
//				break;
//			}
//		}

		for (String child : allWindows) {
			if (driver.switchTo().window(child).getTitle().equals("NxtGen A.I Academy � Automate Intelligently")) {
				break;
			}
		}
		System.out.println("after switching : " + driver.getCurrentUrl());
		driver.close();
		driver.switchTo().window(parent);
		System.out.println(driver.getCurrentUrl());
		driver.quit();

	}

}
