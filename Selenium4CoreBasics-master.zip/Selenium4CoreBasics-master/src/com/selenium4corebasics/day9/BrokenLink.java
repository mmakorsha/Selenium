package com.selenium4corebasics.day9;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class BrokenLink {
	public static void main(String[] args) throws IOException {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.facebook.com/");
		List<WebElement> allLinks = driver.findElements(By.tagName("a"));
		HttpURLConnection con = null;
		for (WebElement element : allLinks) {
			try {
				String link = element.getAttribute("href");
				URL url = new URL(link);
				con = (HttpURLConnection) url.openConnection();
				con.setConnectTimeout(3000);
				con.connect();
				if (con.getResponseCode() == 200) {
					System.out.println(link + " : " + con.getResponseCode());
				} else {
					System.err.println(link + " : " + con.getResponseCode());
				}
			} catch (Exception e) {

			} finally {
				con.disconnect();
			}
		}

	}

}
