package com.selenium4corebasics.day9;

import java.io.File;
import java.time.Duration;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class FileDownloadChrome {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		HashMap<String, Object> pref = new HashMap<>();
		String filePath = System.getProperty("user.dir") + "\\src\\com\\selenium4corebasics\\day9";
		pref.put("download.default_directory", filePath);
		pref.put("plugins.always_open_pdf_externally", true);
		ChromeOptions opt = new ChromeOptions();
		opt.setExperimentalOption("prefs", pref);
		WebDriver driver = new ChromeDriver(opt);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://file-examples.com/index.php/sample-documents-download/sample-pdf-download/");
		WebElement downloadElement = driver.findElement(By.xpath("(//a[text()='Download sample pdf file'])[1]"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", downloadElement);
		Thread.sleep(10000);
		File file = new File(filePath + "\\file-sample_150kB.pdf");
		if (file.exists()) {
			System.out.println("test case passed");
			file.delete();
		} else {
			System.out.println("test case failed");
		}

	}
}
