package com.selenium4corebasics.day9;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FileUpload {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://the-internet.herokuapp.com/upload");
		driver.findElement(By.id("file-upload"))
				.sendKeys(System.getProperty("user.dir") + "\\src\\com\\selenium4corebasics\\day9\\upload.txt");
		driver.findElement(By.id("file-submit")).click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		WebElement ele_success = wait
				.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("uploaded-files"))));
		if (ele_success.getText().contains("uploa.txt")) {
			System.out.println("File uploaded successfully");
		} else {
			System.out.println("File uploaded not successful");
		}

		driver.quit();
	}

}
