package com.selenium4corebasics.day9;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.v113.input.Input.DispatchKeyEventType;
import org.openqa.selenium.interactions.Actions;

import java.awt.AWTException;
import java.awt.Robot;

public class KeyboardActions {

	public static void main(String[] args) throws AWTException {
		System.setProperty("webdriver.chrome.driver",
				System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		WebElement ele_email = driver.findElement(By.id("email"));
		Actions acc = new Actions(driver);
		acc.keyDown(Keys.SHIFT).perform();
		ele_email.sendKeys("sjatsh");
		System.out.println("value : " + ele_email.getAttribute("value"));
		driver.quit();
	}

}
