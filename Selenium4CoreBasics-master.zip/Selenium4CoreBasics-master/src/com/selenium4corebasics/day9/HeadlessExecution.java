package com.selenium4corebasics.day9;

import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

public class HeadlessExecution {

	public static void main(String[] args) {

		String browserName = "firefox";
		WebDriver driver = null;
		if (browserName == "chrome") {
			ChromeOptions opt = new ChromeOptions();
			opt.addArguments("--headless");
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "\\dependencies\\chromedriver.exe");
			driver = new ChromeDriver(opt);
		} else if (browserName == "edge") {
			EdgeOptions opt = new EdgeOptions();
			opt.addArguments("--headless");
			System.setProperty("webdriver.edge.driver",
					System.getProperty("user.dir") + "\\dependencies\\msedgedriver.exe");
			driver = new EdgeDriver(opt);
		} else {
			FirefoxOptions opt = new FirefoxOptions();
			opt.addArguments("--headless");
			System.setProperty("webdriver.gecko.driver",
					System.getProperty("user.dir") + "\\dependencies\\geckodriver.exe");
			driver = new FirefoxDriver(opt);
		}
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.facebook.com/");
		List<WebElement> allLinks = driver.findElements(By.tagName("a"));
		HttpURLConnection con = null;
		for (WebElement element : allLinks) {
			try {
				String link = element.getAttribute("href");
				URL url = new URL(link);
				con = (HttpURLConnection) url.openConnection();
				con.setConnectTimeout(3000);
				con.connect();
				if (con.getResponseCode() == 200) {
					System.out.println(link + " : " + con.getResponseCode());
				} else {
					System.err.println(link + " : " + con.getResponseCode());
				}
			} catch (Exception e) {

			} finally {
				con.disconnect();
			}
		}

		driver.quit();

	}

}
